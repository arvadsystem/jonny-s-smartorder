import { API_URL } from '../utils/constants';

class ApiError extends Error {
  constructor(message, { status, code, data } = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.data = data;
  }
}

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

const readBody = async (response) => {
  const text = await response.text().catch(() => '');
  if (!text) return null;

  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
};

const getCookie = (name) => {
  if (typeof document === 'undefined') return null;

  const match = document.cookie
    .split('; ')
    .find((row) => row.startsWith(`${name}=`));

  if (!match) return null;

  const value = match.split('=').slice(1).join('=');
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
};

export const apiFetch = async (endpoint, method = 'GET', body = null) => {
  const upperMethod = method.toUpperCase();

  const headers = {
    'Content-Type': 'application/json'
  };

  // ✅ CSRF SOLO para métodos que cambian estado
  if (!SAFE_METHODS.has(upperMethod)) {
    const csrf = getCookie('csrf_token');
    if (csrf) headers['X-CSRF-Token'] = csrf;
  }

  const options = {
    method: upperMethod,
    headers,
    credentials: 'include' // envía cookies (HttpOnly JWT)
  };

  if (body !== null && body !== undefined) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(`${API_URL}${endpoint}`, options);

  // 401 -> no autenticado
  if (response.status === 401) {
    const errorData = await readBody(response);
    const msg =
      (errorData && typeof errorData === 'object' && (errorData.message || errorData.mensaje)) ||
      (typeof errorData === 'string' ? errorData : '') ||
      'No autorizado';

      // ✅ HU79/HU82: si el backend dice 401, forzamos logout global en la app
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('auth:logout'));
      }
    throw new ApiError(msg, { status: 401, code: 'UNAUTHORIZED', data: errorData });
  }

  // ✅ 403 -> distinguir permisos vs CSRF
  if (response.status === 403) {
    const errorData = await readBody(response);
    const msg =
      (errorData && typeof errorData === 'object' && (errorData.message || errorData.mensaje)) ||
      (typeof errorData === 'string' ? errorData : '') ||
      'Acceso denegado';

    // Si el método es seguro (GET/HEAD/OPTIONS), NO es CSRF, es FORBIDDEN (RBAC)
    if (SAFE_METHODS.has(upperMethod)) {
      throw new ApiError(msg, { status: 403, code: 'FORBIDDEN', data: errorData });
    }

    // En métodos no seguros, un 403 puede ser CSRF o permisos.
    // Conservamos tu mensaje por compatibilidad.
    throw new ApiError(msg || 'Acción bloqueada (CSRF)', { status: 403, code: 'CSRF', data: errorData });
  }

  // otros errores HTTP
  if (!response.ok) {
    const errorData = await readBody(response);
    const msg =
      (errorData && typeof errorData === 'object' && (errorData.message || errorData.mensaje)) ||
      (typeof errorData === 'string' ? errorData : '') ||
      `Error HTTP: ${response.status}`;

    throw new ApiError(msg, { status: response.status, code: 'HTTP_ERROR', data: errorData });
  }

  if (response.status === 204) return null;

  return await readBody(response);
};
